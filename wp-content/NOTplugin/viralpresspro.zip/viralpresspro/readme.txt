=== ViralPress Pro ===
Contributors: IndigoThemes
Donate link: https://indigothemes.com/donation/
Tags: facebook, social media
Requires at least: 3.0.1
Tested up to: 4.4.2
Stable tag: 1.0.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

ViralPress Pro is the most powerful and unique WordPress plugin to find and analyze viral content from Facebook for any business/niche.

== Description ==

ViralPress Pro is a very easy to use WordPress plugin to find Viral content from Facebook. ViralPress Pro helps you in finding and analyzing the content which went Viral in your business niche. Within a few seconds, you can easily find why is a particular Facebook page so popular by exploring its most popular (Viral) content using ViralPress Pro plugin. 


== Installation ==

This section describes how to install the ViralPress Pro plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/viralpresspro` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->ViralPress Settings screen to configure the Facebook App settings.


== Frequently Asked Questions ==

= What is the documentation URL ? =

Documentation URL is https://indigothemes.com/documentation/viralpresspro/

= What is the main difference between ViralPress Lite and ViralPress Pro plugin ? =

ViralPress Pro is the advanced version of ViralPress Lite. ViralPress Lite has limitations that you only get 10 images/videos when you explore a particular page but in ViralPress Pro, you get unlimited images/videos. ViralPress Pro has filters using which you can sort the data based on total likes and shares and much more. 

== Changelog ==

= 1.0 =
* Release Date - 8th March, 2016
* Initial Launch.

= 1.0.1 =
* Release Date - 9th March, 2016
* Chnages in License Part.
* Add New "FB Support Group" Menu.

= 1.0.2 =
* Release Date - 14th March, 2016
* Changes In Facebook Post Popup Layout.
* Solved Small Issue -Explore Lots Of Page Data.

= 1.0.3 =
* Release Date - 15th March, 2016
* Solved Small Issue In ViralPress Menu.
* Add Processing Popup In Close Option.

= 1.0.4 =
* Release Date - 17th June, 2016
* Changed boostrap-min.css to fix WooCommerce Conflict Issue.

= 1.0.5 =
* Release Date - 23rd June, 2016
* Fixed Constructor Issue.

= 1.1 =
* Release Date - 7th Jan, 2017
* Saving viral content (videos and images) to WordPress media.
* Fixed Likes issue.

== Upgrade Notice ==
No notice as of now. :)
